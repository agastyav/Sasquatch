import random
import time

nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
        27, 28, 29, 30, 31, 32, 33, 34, 35, 36]
play_again = ""
money = 100
print(f"Your balance is {money} tokens.")
time.sleep(1)

# Game loop

while True:
    game = input("\nOdd(O) or Even(E) or High(H) or Low(L)? ").upper()
    while True:
        if game != "O" and game != "E" and game != "H" and game != "L" and game != "B":
            game = input("\nPlease enter either Odd(O) or Even(E) or High(H) or Low(L): ").upper()
        else:
            break
    bet = input("\nHow much would you like to bet? Please enter an integer: ")

    # Check bet

    try:
        int(bet)
    except ValueError:
        time.sleep(1)
        print("\nYour bet wasn't an integer so it will be considered as 0.")
        bet = 0
      
    while True:
        if int(bet) > money:
            bet = input("\nPlease enter a valid amount: ")
        else:
            break

    # Spin

    choice = random.choice(nums)
    print("\nSpinning...\n")
    random.shuffle(nums)
    time.sleep(2)

    # Pick odd

    if game == "O":
        if choice % 2 != 0:
            money += int(bet)
            print(f"You win! You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        else:
            lost = int(bet) * 0.7
            money -= round(lost)
            print(f"I'm sorry, but you lost. You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        play_again = input("Play again? Yes(Y) or No(N): ").upper()

    # Pick even

    if game == "E":
        if choice % 2 == 0:
            money += int(bet)
            print(f"You win! You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        else:
            lost = int(bet) * 0.7
            money -= round(lost)
            print(f"I'm sorry, but you lost. You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        play_again = input("Play again? Yes(Y) or No(N): ").upper()

    # Pick high

    if game == "H":
        if 19 <= choice <= 36:
            money += int(bet)
            print(f"You win! You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        else:
            lost = int(bet) * 0.7
            money -= round(lost)
            print(f"I'm sorry, but you lost. You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        play_again = input("Play again? Yes(Y) or No(N): ").upper()

    # Pick low

    if game == "L":
        if 1 <= choice <= 18:
            money += int(bet)
            print(f"You win! You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        else:
            lost = int(bet) * 0.7
            money -= round(lost)
            print(f"I'm sorry, but you lost. You spun a {choice}. Your new balance is {money} tokens.\n")
            time.sleep(1)
        play_again = input("Play again? Yes(Y) or No(N): ").upper()

    # Play again

    if play_again == "Y":
        print("\nGreat!")
        time.sleep(1)
        continue
    else:
        print("\nExiting game...\n")
        time.sleep(1)
        print("Thanks for playing.")
        break