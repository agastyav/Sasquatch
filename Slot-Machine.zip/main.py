import random
import time
from graphics import Slots_Graphics

Total_cash = 1000

play = True

while play:

    slotsposition = random.randint(0, 26)

    print(f"Here's your balance: {Total_cash}\n")

    money_betted = input("How much money do you want to bet? Please input an amount less than "+ str(Total_cash) + ": ")

    while (int(money_betted) > Total_cash or int(money_betted)<0):
        print("Sorry, you can't bet an amount you don't have. \n")
        money_betted = input("Please print another amount.")

    print("Spinning the slots...")
    time.sleep(2)
    print(Slots_Graphics[slotsposition])

    if (slotsposition == 8 or slotsposition == 17 or slotsposition == 26):
        print(f"Good job! You won {int(money_betted)*3}. Your new balance is {Total_cash+int(money_betted)*3}")
        Total_cash = Total_cash + 3*int(money_betted)
    else:
        print(f"Oops, you lost. Your new balance is {Total_cash-int(money_betted)}")
        Total_cash = Total_cash - int(money_betted)

    playagain = input("Do you want to spin again? Type yes or no.")
    if(playagain == "no"):
      play = False
