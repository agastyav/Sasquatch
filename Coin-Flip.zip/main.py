import random
import time

# Initial setup
heads = """
 -------
| HEADS |
| HEADS |  
 -------
"""
tails = """
 -------
| TAILS |
| TAILS |  
 -------
"""
coins = ["heads", "tails"]

# Game loop
while True:
  flip = input("\nPick Heads(H) or Tails(T): ").upper()
  while True:
    if flip == "H" or flip == "T":
      break
    else:
      flip = input("\nEnter either Heads(H) or Tails(T): ").upper()

  # Coin flip
  print("\nCoin is flipping...")
  land = random.choice(coins)
  time.sleep(1)

  # Pick heads
  if flip == "H":
    if land == "heads":
      print(heads)
      time.sleep(0.5)
      print("You're in luck! You landed a heads.")
    if land == "tails":
      print(tails)
      time.sleep(0.5)
      print("Luck wasn't in your favor this time. You landed a tails.")
    time.sleep(1.5)
    play_again = input("\nPlay again? Yes(Y) or No(N): ").upper()
    if play_again == "Y":
      time.sleep(0.5)
      continue
    else:
      print("\nThanks for playing.")
      break

  # Pick tails
  if flip == "T":
    if land == "tails":
      print(tails)
      time.sleep(0.5)
      print("You're in luck! You landed a tails.")
    if land == "heads":
      print(heads)
      time.sleep(0.5)
      print("Luck wasn't in your favor this time.")
    time.sleep(1.5)
    play_again = input("\nPlay again? Yes(Y) or No(N): ").upper()
    if play_again == "Y":
      time.sleep(0.5)
      continue
    else:
      print("\nThanks for playing.")
      break
  