#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int getint(char* question);

int main(void)
{
  time_t t;
  int num1;
  int num2;
  int num3;
  int cash = 1000;
  int yesNo;
  printf("Welcome to Slots! type in your command to begin.\n");
  printf("P = play | B = balance | E = exit\n");
  char startinput[] = "empty";
  printf("command: ");
  scanf("%s", startinput);
  char B[] = "B";
  char P[] = "P";
  char E[] = "E";
  if(strcmp(startinput, B)==0)
{
    printf("\ncurrent balance: %i", cash);
}

if(strcmp(startinput, E)==0)
{
	yesNo = 0;
}
  if(strcmp(startinput,P)==0)
{
  printf("Current Balance: %d", cash);

  printf("\n");
do
{
  printf("B = balance | E = exit | P = Play\n");
  printf("command: ");
  scanf("%s", startinput);
  if(strcmp(startinput, B)==0)
{
    printf("current balance: %i\n", cash);
	printf("E = exit | P = Play\n");
  	printf("command: ");
  	scanf("%s", startinput);
	if(strcmp(startinput, E)==0)
	{
		printf("Game over. Your final balance was $%d.", cash);
		yesNo = 0;
		exit(0);
	}

}

if(strcmp(startinput, E)==0)
{
	printf("Game over. Your final balance was $%d.", cash);
	yesNo = 0;
	exit(0);
}
  int bet = getint("how much do you want to bet *(note; it costs $5 to bet)? : ");
  printf("\n");
	#include <time.h>
  num1=rand();
	num2=rand();
	num3=rand();
  srand((unsigned) time(&t));
	num1=2+num1%10;
	num2=1+num2%10;
	num3=3+num3%10;
	printf("Spin results: ");
	printf("%d %d %d 	\n", num1, num2, num3);
	if((num1==num2)&&(num2==num3)&&(num3==num1))
	{
		cash=cash-5;
		cash=(20*num1)+cash;
		printf("You got a triple match! You win $%d!\n", 20*num1);
	}
	if((num1!=num2)&&(num2!=num3)&&(num3!=num1))
	{
	cash=cash-bet;
	printf("Sorry, no matches.\n");
    printf("Current Balance: %d\n", cash);

	}
	if(((num1==num2)&&(num2!=num3))||((num2==num3)&&(num1!=num2))||((num1==num3)&&(num1!=num2)))
	{
		printf("You got one match, you win $%d\n", bet);
        cash = cash-5;
        cash = cash+bet;
        printf("Current Balance: %d\n", cash);
	}
yesNo = getint("Would you like to spin Again (Yes=1, No=0)? ");
} while (yesNo==1);
}
printf("Game over. Your final balance was $%d.", cash);
return 0;
}
int getint(char* question)
{
    printf("%s", question);
    int out;
    scanf("%d", &out);
    return out;

}