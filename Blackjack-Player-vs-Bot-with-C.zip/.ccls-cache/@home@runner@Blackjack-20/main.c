#include <stdio.h>
//#include <cs50.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

/*
FIXING CERTAIN ERRORS, SUCH AS LIBRARY DEPENDANCIES
*/

int main(void){

    //bluff graphics
    printf("\n\n|================================|\n|                                |\n|  Welcome to BlackjackTerminal  |\n|                                |\n|================================|\n|                                |\n");
    sleep(2);

    //initializing some things, variables, etc.
    srand(time(NULL));
    int decknum = 0;

/*

PSEUDOCODE/GamePlan:
 - player input for number of players, if number of players is one, then activate the bot
 - number/card set, with variable names as numbers, I am doing this as a array
 - choose random number, then choose the card that is assigned to that number
 - give each player a card, alternately, (cards with the random chosen number)
 - when it is the player's turn, then allow them to have the option to draw a card or to stand
 - when it is time to show cards, auto detect players that go bust, choose final winner, if tie, restart games between remaining players

*/

    //player count
  printf("| How many players are there: ");
  int playercount;
  scanf("%d", &playercount);

  //bluff graphics (again)
  printf("\033[A\33[2K""\033[A\33[2K""| There are currently %i player(s)|\n", playercount);
  printf("|--------------------------------|\n");
  if(playercount == 1)
  {
    printf("|         Activating Bot...      |\n");
    sleep(2);
    printf("\033[A\33[2K|         Bot Activated...       |\n");
    sleep(2);
    printf("|================================|\n");


  }

    // initializing cardsets, for each player
  int players[4][4];


  int bot[4][4];

    //random values for the cards



  int deck[52] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10};

  shuffle(deck, 52);


  if(playercount != 1)
  {
    printf("this feature is not available yet, please re-run and input 1 for the number of players");
  }
  else
  {
    int num = 0;
    for(int i = 0; i < 4; i++)
    {
      players[1][i] = deck[num];
      num++;
    }
    for(int i = 0; i < 4; i++)
    {
      bot[1][i] = deck[num];
      num++;
    }
    botgame(bot, players, deck, num);
    
  }

}

int getint(char* question)
{
    printf("%s", question);
    int out;
    scanf("%d", &out);
    return out;
  
}

int shuffle(int *array, size_t n) {    
    struct timeval tv;
    gettimeofday(&tv, NULL);
    int usec = tv.tv_usec;
    srand48(usec);


    if (n > 1) {
        size_t i;
        for (i = n - 1; i > 0; i--) {
            size_t j = (unsigned int) (drand48()*(i+1));
            int t = array[j];
            array[j] = array[i];
            array[i] = t;
        }
    }
}

int botgame(int bot[4][4], int players[4][4], int deck[52], int num)
{
  
  if(bot[1][1] == 1 && bot[1][2] == 10)
  {
    bot[1][1] = 11;
  }
  else if(bot[1][1] == 10 && bot[1][2] == 1)
  {
    bot[1][2] = 11;
  }
  
  if(players[1][1] == 1 && players[1][2] == 10)
  {
    players[1][1] = 11;
  }
  else if(players [1][1] == 10 && players[1][2] == 1){
    players[1][2] = 11;
  }

  int total = players[1][1] + players[1][2];
  int bot_total = bot[1][1] + bot[1][2];
  printf("|      card 1: %i |", players[1][1]);
  printf(" card 2: %i    |\n", players[1][2]);
  printf("|================================|\n");

  char* H = "H";
  char* S ="S";
  int run = 1;
  int p_num = 2;
  while(run == 1)
  {
    if(total == 21)
    {
      printf("|     You win! Your total, is 21      |");
      run++;
    }

    if(total < 21 && bot_total < 21)
    {
      printf("|          your total: %i        |\n", total);
      char HS;
      printf("|       Hit(H) or stay(S)?:");
      scanf("%s", &HS);
      if(HS=='H')
      {
        printf("\033[A\33[2K|      Hit(H) or stay(S)?: H     |\n");
        printf("|--------------------------------|\n");

        num++;
        //p_num++;
        //players[1][p_num] = deck[num];
        total = total + deck[num];
        num++;
        bot_total = bot_total + deck[num];
        
      }
      else if(HS=='S')
      {
        printf("\033[A\33[2K|      Hit(H) or stay(S)?: S     |\n");

        if(bot_total > total)
        {
          printf("the bot won!\n");
          run++;
        }
        else if(bot_total == total)
        {
          printf("Draw! You and the bot tied.");
          run++;
        }
        else if(bot_total < total)
        {
          printf("you win!");
          run++;
        }
      }

      }
    if(total > 21)
    {
      printf("game over! You busted!\n");
      run++;
    }
    if(bot_total > 21)
    {
      printf("the bot busted! You win\n");
      run++;
    }
      

  }
  return 0;
}
  