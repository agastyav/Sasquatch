name = input("What is your name? ")

def game():

  import random
  
  randominteger = random.randint(1,100)
  
  numberofguesses = 5

  guess = int(input(f"Hello {name}! Guess a number from 1 to 100: "))
  
  while numberofguesses != 0:
  
    if guess < randominteger:
      guess = int(input(f"Bruh, {name}. Your guess was too small. Please try again: "))
      numberofguesses = numberofguesses - 1   
  
    if guess == randominteger:
      print(f"Good job, {name}. You guessed the number rightly.")
      break
        
    if guess > randominteger:
      guess = int(input(f"Too bad, {name}. Your guess was too big. Please try again: "))
      numberofguesses = numberofguesses - 1
  
  if numberofguesses == 0:
    print("Oof, you lost. The correct number was " + str(randominteger))

while True:
  game()
  playagain = int(input("Do you want to play again? Enter 1 for yes and 0 for no."))
  if playagain == 1:
    pass
  else:
    break

print("Nice seeing you here, see you next time!")


