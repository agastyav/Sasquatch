import random
import time

# Player cards
card_1 = random.randint(1, 10)
card_2 = random.randint(1, 10)

# Aces
if card_1 == 1 and card_2 == 10:
    card_1 = 11
if card_2 == 1 and card_1 == 10:
    card_2 = 11

# Inital deck
total = card_1 + card_2
print(f"Player: \nCard 1: {card_1} || Card 2: {card_2}\n")

# Bot deck
bot_card_1 = random.randint(1, 10)
bot_card_2 = random.randint(1, 10)
bot_total = bot_card_1 + bot_card_2
print(f"Bot:\nCard 1: {bot_card_1} || Card 2: ?\n")

# Main Loop
while True:
    if total == 21:
          print(f"You win! Your total is {total} and the bot's total is {bot_total}")
          break
    time.sleep(1)
    choice = input("Hit(H) or stay(S)? ")
    if choice.upper() != "H" and choice.upper() != "S":
          print("\nError. Please enter either (H) or (S)\n")
  
    # Player hits
    if choice.upper() == "H":
        card_3 = random.randint(1, 10)
        total += card_3
        if total > 21:
            print(f"\nGame over. You busted! You're total was {total}.")
            break
        if total == 21:
            print(f"\nYou win! You're total was {total}.")
            break
        if total < 21:
            if bot_total <= 16:
                bot_card_3 = random.randint(1, 10)
                bot_total += bot_card_3
                if bot_total > 21:
                    print(f"\nYou win! Your total is {total} and the bot's total is {bot_total}.")
                    break
                if bot_total == 21:
                    print(f"\nYour total is {total} and the bot's total is {bot_total}.")
                    break
                if bot_total < 21:
                    print(f"\nYour total is {total} and bot's total is {bot_total}.\n")
            else:
                print(f"\nYour total is {total} and bot's total is {bot_total}.\n")
  
    # Player stays
    if choice.upper() == "S":
        if bot_total <= 16 or total > bot_total:
            bot_card_3 = random.randint(1, 10)
            bot_total += bot_card_3
            if bot_total > 21:
                print(f"\nYou win! Your total is {total} and the bot's total is {bot_total}.")
                break
            if bot_total == 21:
                print(f"\nBot wins. Your total is {total} and the bot's total is {bot_total}.")
                break
            if bot_total < 21:
                print(f"\nYour total is {total} and bot's total is {bot_total}\n.")
        if bot_total > total:
            print(f"\nBot wins. Your total is {total} and the bot's total is {bot_total}.")
            break
        if bot_total == total:
            print(f"\nDraw. Your total is {total} and the bot's total is {bot_total}.")
            break
        if bot_total < total:
            print(f"\nYou win! Your total is {total} and the bot's total is {bot_total}.")
            break
  