import random
import time

# Initial setup
time.sleep(0.5)
message = """|-----------------|
| WELCOME TO KENO |
|-----------------|"""
print(message)
time.sleep(1)
money = 100
print(f"\nYou have {money} tokens.")

# Game loop
while True:

  # Bet
  time.sleep(0.5)
  bet = input("\nHow much would you like to bet per guess? ")
  try:
    int(bet)
  except ValueError:
    print("\nYou did not enter an integer, so your bet will be considered as 0.")
    bet = 0
  bet = int(bet)
  if (5*bet) > money or bet < 0:
    print("\nYour bet was either less than or greater than your token count, so it's considered as 0.")
  time.sleep(0.5)
  
  nums = []
  max = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
  
  # Input guess
  def guess(string):
    place = input(f"\nPlease enter your {string} integer: ")
    try:
      int(place)
    except ValueError:
      place = "" + str(random.choice(max))
      print(f"\nYou did not enter an integer, so a random number was generated for you: {place}")
      time.sleep(2)
      
    if int(place) > 40 or int(place) < 1:
      place = "" + str(random.choice(max))
      print(f"\nYour integer was either too large or too small, so a random number was generated for you: {place}")
      time.sleep(2)
      
    for i in nums:
      if i == place:
        place = "" + str(random.choice(max))
        print(f"\nYou have already entered this value, so a random number was generated for you: {place}")
        time.sleep(2) 
    nums.append(place)

  guess("first")
  time.sleep(0.5)
  
  guess("second")
  time.sleep(0.5)
  
  guess("third")
  time.sleep(0.5)
  
  guess("fourth")
  time.sleep(0.5)
  
  guess("fifth")
  time.sleep(0.5)

  # Random numbers
  print("\nTen random numbers are being generated...")
  time.sleep(1.5)
  money -= 5*bet
  
  n1 = random.choice(max)
  max.remove(n1)
  n1 = str(n1)
  
  n2 = random.choice(max)
  max.remove(n2)
  n2 = str(n2)
  
  n3 = random.choice(max)
  max.remove(n3)
  n3 = str(n3)
  
  n4 = random.choice(max)
  max.remove(n4)
  n4 = str(n4)
  
  n5 = random.choice(max)
  max.remove(n5)
  n5 = str(n5)
  
  n6 = random.choice(max)
  max.remove(n6)
  n6 = str(n6)
  
  n7 = random.choice(max)
  max.remove(n7)
  n7 = str(n7)
  
  n8 = random.choice(max)
  max.remove(n8)
  n8 = str(n8)
  
  n9 = random.choice(max)
  max.remove(n9)
  n9 = str(n9)
  
  n10 = random.choice(max)
  max.remove(n10)
  n10 = str(10)
  
  rand_nums = [n1, n2, n3, n4, n5, n6, n7, n8, n9, n10]
  print(f"\nThe random numbers are {n1} {n2} {n3} {n4} {n5} {n6} {n7} {n8} {n9} and {n10}.")
  matches = 0
  time.sleep(2)

  for i in rand_nums:
    for x in nums:
      if i == x:
        matches += 1
        money += round(3*bet)
  print(f"\nYou got {matches} match(es). Your new balance is {money} tokens.")
  print("\n--------------------------------------------")

  # Play again
  play_again = input("\nWould you like to play again? Yes(Y) or No(N): ").upper()
  if play_again == "Y":
    continue
  else:
    print("Thanks for playing.")
    break